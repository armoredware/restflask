__author__ = 'mjd'

COLLECTION = 'wines'

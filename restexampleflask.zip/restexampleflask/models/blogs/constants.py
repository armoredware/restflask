__author__ = 'mjd'

COLLECTION = 'blogs'

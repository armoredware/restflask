__author__ = 'mjd'

COLLECTION = 'posts'

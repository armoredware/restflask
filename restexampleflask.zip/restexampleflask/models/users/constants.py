__author__ = 'mjd'

COLLECTION = 'users'
